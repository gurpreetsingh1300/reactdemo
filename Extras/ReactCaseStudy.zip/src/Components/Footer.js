import React from 'react';

class Footer extends React.Component {
  render() {
    return (
     <footer className="footer" id="footer">
        <div className="container-fluid">
          <center><p className="text-muted credit">React JS casestudy</p></center>
        </div>
      </footer>

    )
  }
}

export default Footer;
